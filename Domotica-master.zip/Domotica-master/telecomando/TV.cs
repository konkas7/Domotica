﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace telecomando
{
    internal class TV
    {

        string produttore;
        string modello;
        string[] connettori;
        string risoluzione;
        bool stato;
        int canale;
        int volume;


        public TV()
        {

            produttore = "Sony";
            modello = "Vs1";
            connettori[0] = "x";
            connettori[1] = "y";
            connettori[2] = "z";
            risoluzione = "1080 x 960";
            stato = false;
            canale = 0;
            volume = 0;
        }

        public void setCanale(int x)
        {
            canale = x;
        }
        public void aumentaCanale()
        {
            canale++;
        }
        public void diminuisciCanale()
        {
            canale--;
        }
        public void aumentaVolume()
        {
            volume++;
        }
        public void diminuisciVolume()
        {
            volume--;
        }
        public void accendi()
        {
            stato = true;
        }
        public void spengi()
        {
            stato = false;
        }
        
    }
}
